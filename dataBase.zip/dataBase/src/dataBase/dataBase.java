package dataBase;

import java.sql.*;
import java.util.Scanner;

public class dataBase {

    public static Scanner scan = new Scanner(System.in);
    public static ResultSet result = null;
    public static Connection connection = null;
    public static Statement statement = null;

    public static void initialization() throws SQLException {
    	 try {
    	 connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "root", "1234");
    	statement = connection.createStatement();
         } catch (Exception exp) {
             exp.printStackTrace();
         }
    }
    
    public static void main(String[] args) throws SQLException {

            initialization();
            HomePage();
            
    }
    public static void HomePage() throws SQLException {
        char answer = 0;
        do {
        	System.out.println("A- Adding a movie\n" +
                    "B- Adding an actor\n" +
                    "C- Adding information about an actor who played in the movie\n" +
                    "D- Performing user queries\n" +
                    "E- Running a parameterized query\r\n" +
                    "F- Finish.");
            answer = scan.next().charAt(0);

            switch (answer) {
                case 'A':
                case 'a':
                    addingMovie();
                    break;
                case 'B':
                case 'b':
                    addingActor();
                    break;
                case 'C':
                case 'c':
                    addingInformation();
                    break;
                case 'D':
                case 'd':
                    userQueries();
                    break;
                case 'E':
                case 'e':
                	ParameterizedQuery.start();
                    break;
                case 'F':
                case 'f':
                	
            }
		} while (answer != 'f' || answer != 'F');
        return;
    }

    public static void addingActor(){
        int actorID;
        String first_name, last_name;

        System.out.println("Insert: ID actor");
        actorID = scan.nextInt();
        scan.nextLine();

        System.out.println("Insert: first name");
        first_name = scan.nextLine();

        System.out.println("Insert: last name");
        last_name = scan.nextLine();

        try {
            PreparedStatement pstmt = statement.getConnection().prepareStatement("INSERT INTO actor(actor_id, first_name, last_name) VALUES (?, ?, ?)");
            pstmt.setInt(1, actorID);
            pstmt.setString(2, first_name);
            pstmt.setString(3, last_name);
            pstmt.executeUpdate();
            pstmt.close();
        }
        catch(Exception SQLException)
        {
        	System.out.println(SQLException);
        	return;
        }

        System.out.println("New actor in DB");
    }
  
    public static void addingMovie() {
        int ID, languageID;
        String title;

        System.out.println("Insert: ID film");
        ID = scan.nextInt();
        scan.nextLine();

        System.out.println("Insert: Title");
        title = scan.nextLine();

        System.out.println("Insert: language");
        languageID = scan.nextInt();
        scan.nextLine();

        try {
            PreparedStatement pstmt = statement.getConnection().prepareStatement("INSERT INTO film(film_id, title, language_id) VALUES (?, ?, ?)");
            pstmt.setInt(1, ID);
            pstmt.setString(2, title);
            pstmt.setInt(3, languageID);
            pstmt.executeUpdate();
            pstmt.close();
        }
        catch(Exception SQLException)
        {
        	System.out.println(SQLException);
        	return;
        }

        System.out.println("New film in DB");
    }
    
    public static void addingInformation() {
    	int actorID;
    	String first_name, last_name, newInformation;

        System.out.println("Insert: actor ID");
        actorID = scan.nextInt();
        scan.nextLine();

        System.out.println("Insert: first name");
        first_name = scan.nextLine();

        System.out.println("Insert: last name");
        last_name = scan.nextLine();
        
        System.out.println("Insert: new information");
        newInformation = scan.nextLine();
        
        

        try {
        	String sql = "UPDATE actor_info SET film_info = CONCAT(film_info, ', ', ?) WHERE actor_id = ?";
        	PreparedStatement pstmt = statement.getConnection().prepareStatement(sql);
        	pstmt.setString(1, "new_information");
        	pstmt.setInt(2, actorID);
        	pstmt.executeUpdate();
        }
        catch(Exception SQLException)
        {
        	System.out.println(SQLException);
        	return;
        }

        System.out.println("New information in DB");
    }
    
    public static void userQueries() {
    scan.nextLine();
    String query;
    System.out.println("Please insert your query:");
    query = scan.nextLine();

    try {
        result = statement.executeQuery(query);
        print(false);

    } catch (SQLException e) {
        System.out.println("An error occurred: " + e.getMessage());
    }
}

    public static void print(boolean printRows) throws SQLException
    {
    	if (!result.isBeforeFirst()) {
    	    System.out.println("No results found.");
    	    return;
    	}
    	
    	 int counterColumn = 0;
         if (result.next())
         { 
             while (true)
             {
                 try
                 {
                     result.getString(++counterColumn);
                 } 
                 catch (SQLException e)
                 {
                     break;
                 }
             }
         }
         do {
             for (int i = 1; i < counterColumn; i++) 
             {
                 System.out.print(result.getString(i) + "\t");
             }
             System.out.println();
         } while (result.next());
         
         if(printRows)
         {
        	 System.out.println("Number of rows: " + (counterColumn-1));
         }
    }
     
}

class ParameterizedQuery
{      
	public static void start()
	{
		char answer = 0;
    	String input,firstName,lastName;
    	int countOfActors;
        System.out.println("a. Search for a movie by a word in the movie title\n"
        		+ "b. Search for all movies in which an actor has appeared by the actor's name\n"
        		+ "c. Search for all actors who have appeared in movies in a specific language by the language\n"
        		+ "d. Search for a movie that, according to the database, has exactly X actors in it\n"
        		+ "e. Search for an English-language movie that Robert De Niro did not star in\n"
        		+ "f. The number of movies in which an actor has appeared by the actor's name");
        answer = dataBase.scan.next().charAt(0);

        switch (answer) {
            case 'A':
            case 'a':
            	System.out.println("Insert title");
            	dataBase.scan.nextLine();
                input = dataBase.scan.nextLine();
			try {
					dataBase.result = dataBase.statement.executeQuery("select * from film where title = '" + input + "'");
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                break;
            case 'B':
            case 'b':
            	System.out.println("Insert first name");
            	dataBase.scan.nextLine();
            	firstName = dataBase.scan.nextLine();
            	System.out.println("Insert last name");
            	lastName = dataBase.scan.nextLine();
			try {
					dataBase.result = dataBase.statement.executeQuery("SELECT title \r\n"
							+ "FROM film \r\n"
							+ "WHERE film_id IN (\r\n"
							+ "    SELECT film_id \r\n"
							+ "    FROM film_actor \r\n"
							+ "    WHERE actor_id IN (\r\n"
							+ "        SELECT actor_id \r\n"
							+ "        FROM actor \r\n"
							+ "        WHERE first_name = '"+firstName+"' AND last_name = '"+lastName+"'\r\n"
							+ "    )\r\n"
							+ ");\r\n"
							+ "");
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                break;
            case 'C':
            case 'c':
            	System.out.println("Insert language");
            	dataBase.scan.nextLine();
                input = dataBase.scan.nextLine();
			try {
					dataBase.result = dataBase.statement.executeQuery("SELECT first_name, last_name \r\n"
							+ "FROM actor\r\n"
							+ "WHERE actor_id IN (\r\n"
							+ "    SELECT actor_id \r\n"
							+ "    FROM film_actor \r\n"
							+ "    WHERE film_id IN (\r\n"
							+ "        SELECT film_id \r\n"
							+ "        FROM film \r\n"
							+ "        WHERE language_id IN (\r\n"
							+ "            SELECT language_id \r\n"
							+ "            FROM language \r\n"
							+ "            WHERE name = '"+input+"'\r\n"
							+ "        )\r\n"
							+ "    )\r\n"
							+ ");\r\n"
							+ "");
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                break;
            case 'D':
            case 'd':
            	System.out.println("Insert count of actors");
            	dataBase.scan.nextLine();
                countOfActors = dataBase.scan.nextInt();
			try {
					dataBase.result = dataBase.statement.executeQuery("SELECT f.title \r\n"
							+ "FROM film f\r\n"
							+ "JOIN film_actor f2 ON f1.film_id = f2.film_id\r\n"
							+ "GROUP BY f1.film_id, f1.title\r\n"
							+ "HAVING COUNT(fa.actor_id) = "+ countOfActors);
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                break;
            case 'E':
            case 'e':
            	for(int i = 0 ; i < 3 ; i++)
            	{
            		System.out.println("Searching");
            		try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
            	}
            	try {
					dataBase.result = dataBase.statement.executeQuery("SELECT title\r\n"
							+ "FROM film\r\n"
							+ "WHERE language_id IN (\r\n"
							+ "    SELECT language_id\r\n"
							+ "    FROM language\r\n"
							+ "    WHERE name = 'English'\r\n"
							+ ") \r\n"
							+ "AND film_id NOT IN (\r\n"
							+ "    SELECT film_id\r\n"
							+ "    FROM film_actor fa\r\n"
							+ "    JOIN actor a ON fa.actor_id = a.actor_id\r\n"
							+ "    WHERE a.first_name = 'Robert' AND a.last_name = 'De Niro'\r\n);");
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                break;
            case 'F':
            case 'f':
            	System.out.println("Insert first name");
            	dataBase.scan.nextLine();
            	firstName = dataBase.scan.nextLine();
            	System.out.println("Insert last name");
            	lastName = dataBase.scan.nextLine();
			try {
					dataBase.result = dataBase.statement.executeQuery("select count(film_id)\r\n"
							+ "from film_actor\r\n"
							+ "where actor_id IN(\r\n"
							+ "					select actor_id\r\n"
							+ "                    from actor\r\n"
							+ "                    where first_name = '"+firstName+"' and last_name = '"+lastName+"')");
					dataBase.print(true);
				} catch (SQLException e) {
					e.printStackTrace();
			}
                return;
        }
	}

}